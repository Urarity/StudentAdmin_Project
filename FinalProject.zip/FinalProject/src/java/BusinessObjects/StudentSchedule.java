package BusinessObjects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/********************************************************************
 *	Java III - Business Object
 * 	Patricia Rivera	- Spring 2020
 *            StudentSchedule.java
 ********************************************************************/
public class StudentSchedule {
    /*** Properties **/
    String studentID;
    String crn;
    String error;
    
    // Schedule List
    public List<String> ssList = new ArrayList<String>();
    
    public StudentSchedule(){
        this.studentID = "";
        this.crn = "";
    }
    
    public StudentSchedule(String id, String crn){
        this.studentID = id;
        this.crn = crn;
    }
    
/**********************************************************************
 *                  Setter / Getters
 **********************************************************************/
    
    // Set & get ID
    public void setID(String id){
        this.studentID = id;
    }
    
    public String getID(){
        return this.studentID;
    }
    
    // Set & get crn
    public void setCRN(String crn){
        this.crn = crn;
    }
    
    public String getCRN(){
        return this.crn;
    }
    
    // Set & get error
    public void setError(String error){
        this.error = error;
    }
    
    public String getError(){
        return this.error;
    }
    
/**********************************************************************
 *                  Database Behaviors
 *                      Course.java
 **********************************************************************/
    
/**********************************************************************
 *                  Get StudentSchedule by Student ID
 **********************************************************************/  
    public void selectDB(String id){
        
        Section s1 = new Section();
        Instructor i1 = new Instructor();
        
        // Set ID
        setID(id);
                
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
           
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM StudentSchedule WHERE StudentID = '"+getID()+"'";

            ResultSet rs = stmt.executeQuery(sql);
            
            int count = 3;
            
            // Run statement
            while(rs.next()){
                ssList.add(rs.getString(1));
                ssList.add(rs.getString(2));
                
                s1.selectSectionDB(rs.getInt(2));
                i1.selectDB(Integer.parseInt(s1.sList.get(count)));
                ssList.add(i1.getInstructorFN());
                ssList.add(i1.getInstructorLN());
                
                count = count + 5;
            }
            
            // Close result
            rs.close();
            
            // Close connection
            c1.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
/**********************************************************************
 *                  Get StudentSchedule by crn
 **********************************************************************/  
    public void selectDbByCRN(String crn){
        
        Section s1 = new Section();
        Instructor i1 = new Instructor();
        
        // Set ID
        setCRN(crn);
                
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
           
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM StudentSchedule WHERE CRN = '"+getCRN()+"'";

            ResultSet rs = stmt.executeQuery(sql);
            
            int count = 3;
            
            // Run statement
            while(rs.next()){
                ssList.add(rs.getString(1));
                ssList.add(rs.getString(2));
                
                s1.selectSectionDB(rs.getInt(2));
                i1.selectDB(Integer.parseInt(s1.sList.get(count)));
                ssList.add(i1.getInstructorFN());
                ssList.add(i1.getInstructorLN());
                
                count = count + 5;
            }
            
            // Close result
            rs.close();
            
            // Close connection
            c1.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
/**********************************************************************
 *                  insert New StudentSchedule to DB
 **********************************************************************/  
    public void insertDB(){
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
            "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL Statement
            Statement stmt = c1.createStatement();
            
            String sql = "Insert into StudentSchedule values('"+getID()+"',"+
                                        "'"+getCRN()+"')";
            
            // Check if update was successfull or not
            int n1 = stmt.executeUpdate(sql);
            if(n1 == 1){
                System.out.println("Update Successfull!");
                setError("Your Class Was added");
            }
            else{
                System.out.println("Update failed!");
                setError("It Failed");
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(StudentSchedule.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**********************************************************************
 *                  Delete StudentSchedule from DB
 **********************************************************************/     
    public void deleteDB(){
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" +
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            //Execute SQL Statement
            Statement stmt = c1.createStatement();
            String sql = "DELETE from StudentSchedule WHERE StudentID = '"+getID()+"' AND CRN = '"+getCRN()+"'";
            
            // Print out sql
            System.out.println(sql);

            // Check if Delete worked
            int n = stmt.executeUpdate(sql);

            if (n==1)
                System.out.println("Delete Successful!");
            else
                System.out.println("Delete failed!");
            c1.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
/**********************************************************************
 *                  Show Information
 **********************************************************************/  
    public void ssDisplay(){
        int count = 1;
        int count2 = 2;
        int count3 = 3;
        
        System.out.println("=========================");
        for (int i = 0; i < ssList.size(); i++){
            System.out.println(ssList.get(i) + " " + ssList.get(count));
            System.out.println("Teacher Name: " + ssList.get(count2) + " " + ssList.get(count3) );
            
            count3 = count3 + 4;
            count2 = count2 + 4;
            count = count + 4;
            i = i + 3;
        }
        System.out.println("=========================");
    }
    
    public static void main(String[] args){
        
        StudentSchedule ss = new StudentSchedule();
        
//        ss.selectDB("1");
        
        
//        ss.ssDisplay();
//        ss.setID("1");
//        ss.setCRN("30111");
//        
//        ss.deleteDB();
        
//       ss.insertDB();

       StudentSchedule s1 = new StudentSchedule();
       
       s1.selectDB("1");
       
       s1.ssDisplay();
    }
}
