package BusinessObjects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
/********************************************************************
 *	Java III - Student Business Object
 * 	Patricia Rivera	- Spring 2020
 *            Student.java
 ********************************************************************/
public class Student {
    // ***************** Properties **************************** 
    private int studentID;
    private String studentPass;
    private String studentFN;
    private String studentLN;
    private String studentStreet;
    private String studentCity;
    private String studentState;
    private int studentZip;
    private String studentEmail;
    private int studentGPA;
    private String error;
    private String student;
    
    public List<String> studentList = new ArrayList<String>();
    
    // ***************** Constructors **************************** 
    public Student(){
        this.studentID = 0;
        this.studentPass = "";
        this.studentFN = "";
        this.studentLN = "";
        this.studentStreet = "";
        this.studentCity = "";
        this.studentState = "";
        this.studentZip = 0;
        this.studentEmail = "";
        this.studentGPA = 0;
        this.error = "";
    }
    
    public Student(int id, String pass, String firstName, String lastName, 
            String street, String city, String state, int zip, String email,
            int gpa){
        this.studentID = id;
        this.studentPass = pass;
        this.studentFN = firstName;
        this.studentLN = lastName;
        this.studentStreet = street;
        this.studentCity = city;
        this.studentState = state;
        this.studentZip = zip;
        this.studentEmail = email;
        this.studentGPA = gpa;
        
    }
    
/**********************************************************************
 *                  Setter / Getters
 **********************************************************************/
    
    // Set & get studentID
    public void setStudentID(int id){
        this.studentID = id;
    }
    
    public int getStudentID(){
        return this.studentID;
    }
    
    // Set & get studentPass
    public void setStudentPass(String pass){
        this.studentPass = pass;
    }
    
    public String getStudentPass(){
        return this.studentPass;
    }
    
    // Set & get studentFN
    public void setStudentFN(String firstName){
        this.studentFN = firstName;
    }
    
    public String getStudentFN(){
        return this.studentFN;
    }
    
    // Set & get studentLN
    public void setStudentLN(String lastName){
        this.studentLN = lastName;
    }
    
    public String getStudentLN(){
        return this.studentLN;
    }
    
    // Set & get street
    public void setStreet(String street){
        this.studentStreet = street;
    }
    
    public String getStreet(){
        return this.studentStreet;
    }
    
    // Set & get city
    public void setCity(String city){
        this.studentCity = city;
    }
    
    public String getCity(){
        return this.studentCity;
    }
    
    // Set & get state
    public void setState(String state){
        this.studentState = state;
    }
    
    public String getState(){
        return this.studentState;
    }
    
    // Set & get zip
    public void setZip(int zip){
        this.studentZip = zip;
    }
    
    public int getZip(){
        return this.studentZip;
    }
    
    // Set & get email
    public void setEmail(String email){
        this.studentEmail = email;
    }
    
    public String getEmail(){
        return this.studentEmail;
    }
    
    // Set & get gpa
    public void setGPA(int gpa){
        this.studentGPA = gpa;
    }
    
    public int getGPA(){
        return this.studentGPA;
    }
    
    // Set & get error
    public void setError(String error){
        this.error = error;
    }
    
    public String getError(){
        return this.error;
    }
    
    // Set & get student
    public void setStudent(String student){
        this.student = student;
    }
    
    public String getStudent(){
        return this.student;
    }
    
/**********************************************************************
 *                  Database Behaviors
 *                      Course.java
 **********************************************************************/
    
/**********************************************************************
 *                  Get Student by ID
 **********************************************************************/  
    public void selectDB(int id){
        // Set ID
        setStudentID(id);
                
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");

            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Students WHERE ID = '"+getStudentID()+"'";
            
            ResultSet rs = stmt.executeQuery(sql);
            
            // Run statement
            rs.next();
            setStudentID(rs.getInt(1));
            setStudentFN(rs.getString(2));
            setStudentLN(rs.getString(3));
            setStreet(rs.getString(4));
            setCity(rs.getString(5));
            setState(rs.getString(6));
            setZip(rs.getInt(7));
            setEmail(rs.getString(8));
            setGPA(rs.getInt(9));
            setStudentPass(rs.getString(10));
            
            // Close connection
            c1.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
/**********************************************************************
 *                  Get Student by Login / firstName, lastName, pass
 **********************************************************************/  
    public void selectLoginDB(String firstName, String lastName, String pass){
        // Set ID, FirstName, LastName
        setStudentFN(firstName);
        setStudentLN(lastName);
                
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * from Students WHERE FirstName = '"+getStudentFN()+"' AND LastName = '"+getStudentLN()+"'";
            
            ResultSet rs = stmt.executeQuery(sql);
            
            // Run statement
            if(rs.next()){
                setStudentID(rs.getInt(1));
                setStudentFN(rs.getString(2));
                setStudentLN(rs.getString(3));
                setStreet(rs.getString(4));
                setCity(rs.getString(5));
                setState(rs.getString(6));
                setZip(rs.getInt(7));
                setEmail(rs.getString(8));
                setGPA(rs.getInt(9));
                setStudentPass(rs.getString(10));
                
                if(pass.equals(getStudentPass())){  
                    // Connect StudentSchedule
                    Student s1 = new Student();
                    StudentSchedule ss1 = new StudentSchedule();
                    ss1.selectDB(Integer.toString(s1.getStudentID()));
                    
                    // Close connection
                    c1.close();
                }
                else{
                    // Close connection
                    c1.close();
                    // setError
                    setError(getStudentFN() + " " + getStudentLN() + " your password is Invalid");
                }
            }
            else{
                // Close connection
                c1.close();
                // setError
                setError("User " + getStudentFN() + " " + getStudentLN() + " Does not exist in our Database");
            }
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
/**********************************************************************
 *                  Get All Students
 **********************************************************************/  
    public void getAllStudents(){
            
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Students";
            
            ResultSet rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                studentList.add(rs.getString(1));
                studentList.add(rs.getString(2));
                studentList.add(rs.getString(3));
                studentList.add(rs.getString(4));
                studentList.add(rs.getString(5));
                studentList.add(rs.getString(6));
                studentList.add(rs.getString(7));
                studentList.add(rs.getString(8));
                studentList.add(rs.getString(9));
                studentList.add(rs.getString(10));
            }
            
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**********************************************************************
 *                  Update Student
 **********************************************************************/      
    public void updateStudent(){
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            // Execute SQL Statement
            Statement stmt = c1.createStatement();
            
            String sql = "UPDATE Students SET FirstName = '"+getStudentFN()+"',"
                    + "LastName = '"+getStudentLN()+"',Street = '"+getStreet()+"',"
                    + "City = '"+getCity()+"',State = '"+getState()+"',"
                    + "Zip = '"+getZip()+"',EMail = '"+getEmail()+"'"
                    + " WHERE ID = '"+getStudentID()+"'";
            
            // Check if update was successfull or not
            int n1 = stmt.executeUpdate(sql);
            if(n1 == 1){
                System.out.println("Update Successfull!");
                setError("Update Was Successfull");
            }
            else{             
                System.out.println("Update failed!");
                setError("Update Failed!");
            }
            
            // Close connection
            c1.close();
            
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   
/**********************************************************************
 *                  Get next ID for new Student
 **********************************************************************/  
    public void getNextID(){
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");

            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Students";

            ResultSet rs = stmt.executeQuery(sql);

            // Run statement
            while(rs.next()){
                setStudentID(rs.getInt(1));
                setStudentFN(rs.getString(2));
                setStudentLN(rs.getString(3));
                setStreet(rs.getString(4));
                setCity(rs.getString(5));
                setState(rs.getString(6));
                setZip(rs.getInt(7));
                setEmail(rs.getString(8));
                setGPA(rs.getInt(9));
                setStudentPass(rs.getString(10));
            }
            
            int num = getStudentID();
            
            setStudentID(num + 1);
            
            // Close connection
            c1.close();

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**********************************************************************
 *                  Insert new Student into DB
 **********************************************************************/      
    public void insertStudentDB(){
        
        try {
             // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
            "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            // Execute SQL Statement
            Statement stmt = c1.createStatement();

            String sql = "INSERT INTO Students(ID, Password, FirstName, LastName, Street, City, State, Zip, EMail, GPA) "
                    + "VALUES('"+getStudentID()+"',"+
                    "'"+getStudentPass()+"',"+ 
                    "'"+getStudentFN()+"',"+
                    "'"+getStudentLN()+"',"+
                    "'"+getStreet()+"',"+
                    "'"+getCity()+"',"+
                    "'"+getState()+"',"+
                    "'"+getZip()+"',"+
                    "'"+getEmail()+"',"+
                    "'"+getGPA()+"')";


            // Check if update was successfull or not
            int n1 = stmt.executeUpdate(sql);
            if(n1 == 1){
                System.out.println("Update Successfull!");
            }
            else{
                System.out.println("Update failed!");
            }
            
            // Close connection
            c1.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    } 

/**********************************************************************
 *                  Delete Student from DB
 **********************************************************************/  
    public void deleteDB(){
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" +
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            //Execute SQL Statement
            Statement stmt = c1.createStatement();
            String sql = " Delete from Students where ID = " + getStudentID();
            
            // Print out sql
            System.out.println(sql);

            // Check if Delete worked
            int n = stmt.executeUpdate(sql);

            if (n==1)
                System.out.println("Delete Successful!");
            else
                System.out.println("Delete failed!");
            c1.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

/**********************************************************************
 *                  Display Information
 **********************************************************************/      
    public void studentDisplay(){
        System.out.println("==========================================");
        System.out.println("ID: " + getStudentID());
        System.out.println("Password: " + getStudentPass());
        System.out.println("First Name: " + getStudentFN());
        System.out.println("Last Name: " + getStudentLN());
        System.out.println("Street: " + getStreet());
        System.out.println("City: " + getCity());
        System.out.println("State: " + getState());
        System.out.println("Zip: " + getZip());
        System.out.println("Email: " + getEmail());
        System.out.println("GPA: " + getGPA());
        System.out.println("==========================================");
    }
    
    public void displayAllStudents(){
        
        System.out.println(studentList);
        
        System.out.println("**********************");
        
        int count = 1;
        int count2 = 2;
        int count3 = 3;
        int count4 = 4;
        int count5 = 5;
        int count6 = 6;
        int count7 = 7;
        int count8 = 8;
        int count9 = 9;
        
        for(int i = 0; i < studentList.size(); i++){
            System.out.println("**********************");
            System.out.println("ID: " + studentList.get(i));
            System.out.println("First Name: " + studentList.get(count));
            System.out.println("Last Name: " + studentList.get(count2));
            System.out.println("Street: " + studentList.get(count3));
            System.out.println("City: " + studentList.get(count4));
            System.out.println("State: " + studentList.get(count5));
            System.out.println("Zip: " + studentList.get(count6));
            System.out.println("Email: " + studentList.get(count7));
            System.out.println("GPA: " + studentList.get(count8));
            System.out.println("Password: " + studentList.get(count9));
            System.out.println("**********************");
            
            count =  count + 10;
            count2 = count2 + 10;
            count3 = count3 + 10;
            count4 = count4 + 10;
            count5 = count5 + 10;
            count6 = count6 + 10;
            count7 = count7 + 10;
            count8 = count8 + 10;
            count9 = count9 + 10;
            i = i + 9;
        }
    }
    
    public static void main(String[] args){
        
        Student s1 = new Student();
       
        s1.getNextID();
        s1.setStudentPass("123");
        s1.setStudentFN("Patricia");
        s1.setStudentLN("Rivera");
        s1.setStreet("Random St.");
        s1.setCity("Fairburn");
        s1.setState("GA");
        s1.setZip(12345);
        s1.setEmail("example@gmail.com");
        s1.setGPA(0);
        
        s1.insertStudentDB();
        
        Student s2 = new Student();
        
        s2.getAllStudents();
        
        s2.displayAllStudents();
        
//        s1.selectLoginDB("Larry","Jones", "1234");
//  
//        s1.studentDisplay();

//        s1.getAllStudents();
//        
//        s1.displayAllStudents();
//        
//        s1.getNextID();
//
//        System.out.println(s1.getStudentID());
//        s1.setStudentID(1);
//        s1.setStudentFN("Larry");
//        s1.setStudentLN("Jones");
//        s1.setStreet("200 Larue St.");
//        s1.setCity("Denver");
//        s1.setState("CO");
//        s1.setZip(89721);
//        s1.setEmail("larry@yahoo.com");
//        
//        s1.updateStudent();
//        
//        Student s2 = new Student();
//        
//        s2.selectDB(1);
//        
//        s2.studentDisplay();
        
    }
}
