package BusinessObjects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/********************************************************************
 *	Java III - Course Business Object
 * 	Patricia Rivera	- Spring 2020
 *            Course.java
 ********************************************************************/
public class Course {
    // ***************** Properties ****************************
    String courseID;
    String courseName;
    String courseDescription;
    int courseCreditHours;
    
    // Course List
    public List<String> courseList = new ArrayList<String>();
    
    public Course(){
        this.courseID = "";
        this.courseName = "";
        this.courseDescription = "";
        this.courseCreditHours = 0;
    }
    
/**********************************************************************
 *                  Setter / Getters
 **********************************************************************/
    
    // Set & get courseID
    public void setCourseID(String courseID){
        this.courseID = courseID;
    }
    
    public String getCourseID(){
        return this.courseID;
    }
    
    // Set & get courseName
    public void setCourseName(String courseName){
        this.courseName = courseName;
    }
    
    public String getCourseName(){
        return this.courseName;
    }
    
    // Set & get description
    public void setCourseDescription(String description){
        this.courseDescription = description;
    }
    
    public String getCourseDescription(){
        return this.courseDescription;
    }
    
    // Set & get creditHours
    public void setCourseCreditHours(int creditHours){
        this.courseCreditHours = creditHours;
    }
    
    public int getCourseCreditHours(){
        return this.courseCreditHours;
    }
    
/**********************************************************************
 *                  Database Behaviors
 *                      Course.java
 **********************************************************************/

/**********************************************************************
 *                  Get Course By courseID
 **********************************************************************/    
    public void selectCourseIdDB(String courseID){
        // Set courseID        
        setCourseID(courseID);
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Courses WHERE CourseID = '"+getCourseID()+"'";
            
            ResultSet rs = stmt.executeQuery(sql);
            
            // Run statement
            rs.next();
            
            setCourseID(rs.getString(1));
            setCourseName(rs.getString(2));
            setCourseDescription(rs.getString(3));
            setCourseCreditHours(rs.getInt(4));
            
            // Close result
            rs.close();
            
            // Close connection
            c1.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
/**********************************************************************
 *                  Get All Courses
 **********************************************************************/  
    public void getAllCourses(){
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Courses";
            
            ResultSet rs = stmt.executeQuery(sql);
            
            // Run statement
            while(rs.next()){
                
                courseList.add(rs.getString(1));
                courseList.add(rs.getString(2));
                courseList.add(rs.getString(3));
                courseList.add(rs.getString(4));
                
            }
            // Close result
            rs.close();
            
            // Close connection
            c1.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }       
    }

/**********************************************************************
 *                 Insert into Course Table
 **********************************************************************/      
    public void insertCourseDB(){
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
            "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL Statement
            Statement stmt = c1.createStatement();
            
            String sql = "INSERT INTO Courses(CourseID, CourseName, Description, CreditHours) "
                    + "VALUES('"+getCourseID()+"',"+
                            "'"+getCourseName()+"',"+ 
                            "'"+getCourseDescription()+"',"+
                            "'"+getCourseCreditHours()+"')";
            
            // Check if update was successfull or not
            int n1 = stmt.executeUpdate(sql);
            if(n1 == 1){
                System.out.println("Update Successfull!");
            }
            else{
                System.out.println("Update failed!");
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(StudentSchedule.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

/**********************************************************************
 *                  Delete Course from table
 **********************************************************************/      
    public void courseDelete(){
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" +
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            //Execute SQL Statement
            Statement stmt = c1.createStatement();
            String sql = " Delete from Sections where CRN = " + getCourseID();
            
            // Print out sql
            System.out.println(sql);

            // Check if Delete worked
            int n = stmt.executeUpdate(sql);

            if (n==1)
                System.out.println("Delete Successful!");
            else
                System.out.println("Delete failed!");
            c1.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
/**********************************************************************
 *                  Display information
 **********************************************************************/  
    public void courseDisplay(){
        System.out.println("==========================================");
        System.out.println("Course ID: " + getCourseID());
        System.out.println("Course Name: " + getCourseName());
        System.out.println("Course Description: " + getCourseDescription());
        System.out.println("Course Credit Hours: " + getCourseCreditHours());
        System.out.println("==========================================");    
    }
    
    public void displayCourse(){
        int count = 1;
        int count2 = 2;
        int count3 = 3;
        
        System.out.println("=========================");
        for (int i = 0; i < courseList.size(); i++){
            System.out.println("CourseID: " + courseList.get(i));
            System.out.println("CourseName: " + courseList.get(count));
            System.out.println("Description: " + courseList.get(count2));
            System.out.println("CreditHours: " + courseList.get(count3));
            System.out.println("******************************");
            count3 = count3 + 4;
            count2 = count2 + 4;
            count = count + 4;
            i = i + 3;
        }
        System.out.println("=========================");
    }
    
    public static void main(String[] args){
        
        Course c1 = new Course();
        
//        c1.selectCourseIdDB("CIST 1001");
//        
//        c1.courseDisplay();
    
        c1.getAllCourses();
        
        c1.displayCourse();
    }
}
