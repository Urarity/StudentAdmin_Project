package BusinessObjects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/********************************************************************
 *	Java III - Instructor Business Object
 * 	Patricia Rivera	- Spring 2020
 *            Instructor.java
 ********************************************************************/
public class Instructor {
    // ***************** Properties ****************************
    int instructorID;
    String instructorFN;
    String instructorLN;
    String instructorStreet;
    String instructorCity;
    String instructorState;
    int instructorZip;
    String instructorOffice;
    String instructorEmail;
    String error;
    String instructor;
    
    public List<String> instructorList = new ArrayList<String>();
    
    public Instructor(){
        this.instructorID = 0;
        this.instructorFN = "";
        this.instructorLN = "";
        this.instructorStreet = "";
        this.instructorCity = "";
        this.instructorState = "";
        this.instructorZip = 0;
        this.instructorOffice = "";
        this.instructorEmail = "";
    }
    
/**********************************************************************
 *                  Setter / Getters
 **********************************************************************/
    
    // Set & get instructorID
    public void setInstructorID(int id){
        this.instructorID = id;
    }
    
    public int getInstructorID(){
        return this.instructorID;
    }
    
    // Set & get instructorFN
    public void setInstructorFN(String fName){
        this.instructorFN = fName;
    }    
    
    public String getInstructorFN(){
        return this.instructorFN;
    }
    
    // Set & get instructorLN
    public void setInstructorLN(String lName){
        this.instructorLN = lName;
    }
    
    public String getInstructorLN(){
        return this.instructorLN;
    }
        
    // Set & get instructorStreet
    public void setInstructorStreet(String street){
        this.instructorStreet = street;
    }
    
    public String getInstructorStreet(){
        return this.instructorStreet;
    }
    
    // Set & get instructorCity
    public void setInstructorCity(String city){
        this.instructorCity = city;
    }
    
    public String getInstructorCity(){
        return this.instructorCity;
    }
    
    // Set & get instructorState
    public void setInstructorState(String state){
        this.instructorState = state;
    }
    
    public String getInstructorState(){
        return this.instructorState;
    }
    
    // Set & get instructorZip
    public void setInstructorZip(int zip){
        this.instructorZip = zip;
    }
    
    public int getInstructorZip(){
        return this.instructorZip;
    }
    
    // Set & get instructorOffice
    public void setInstructorOffice(String office){
        this.instructorOffice = office;
    }
    
    public String getInstructorOffice(){
        return this.instructorOffice;
    }
    
    // Set & get instructorEmail
    public void setInstructorEmail(String email){
        this.instructorEmail = email;
    }
    
    public String getInstructorEmail(){
        return this.instructorEmail;
    }
    
    // Set & get error
    public void setError(String error){
        this.error = error;
    }
    
    public String getError(){
        return this.error;
    }
    
    // Set & get instructor
    public void setInstructor(String instructor){
        this.instructor = instructor;
    }
    
    public String getInstructor(){
        return this.instructor;
    }
    
/**********************************************************************
 *                  Database Behaviors
 *                      Course.java
 **********************************************************************/
    
/**********************************************************************
 *                  Get Instructor By ID
 **********************************************************************/  
    public void selectDB(int id){
        // Set ID
        setInstructorID(id);
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Instructors WHERE ID = '"+getInstructorID()+"'";
            
            ResultSet rs = stmt.executeQuery(sql);
            
            // Run statement
            rs.next();
            
            setInstructorID(rs.getInt(1));
            setInstructorFN(rs.getString(2));
            setInstructorLN(rs.getString(3));
            setInstructorStreet(rs.getString(4));
            setInstructorCity(rs.getString(5));
            setInstructorState(rs.getString(6));
            setInstructorZip(rs.getInt(7));
            setInstructorOffice(rs.getString(8));
            setInstructorEmail(rs.getString(9));
            
            // Close connection
            c1.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
/**********************************************************************
 *                  Get All Instructors
 **********************************************************************/  
    public void getAllInstructors(){
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Instructors";
            
            ResultSet rs = stmt.executeQuery(sql);
            
            // Run statement

            while(rs.next()){
                instructorList.add(rs.getString(1));
                instructorList.add(rs.getString(2));
                instructorList.add(rs.getString(3));
                instructorList.add(rs.getString(4));
                instructorList.add(rs.getString(5));
                instructorList.add(rs.getString(6));
                instructorList.add(rs.getString(7));
                instructorList.add(rs.getString(8));
                instructorList.add(rs.getString(9));
            }
            
            // Close connection
            c1.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**********************************************************************
 *                  Get the Next ID for new Instructor
 **********************************************************************/      
    public void getNextID(){
            try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");

            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Instructors";

            ResultSet rs = stmt.executeQuery(sql);

            // Run statement

            while(rs.next()){
                setInstructorID(rs.getInt(1));
                setInstructorFN(rs.getString(2));
                setInstructorLN(rs.getString(3));
                setInstructorStreet(rs.getString(4));
                setInstructorCity(rs.getString(5));
                setInstructorState(rs.getString(6));
                setInstructorZip(rs.getInt(7));
                setInstructorOffice(rs.getString(8));
                setInstructorEmail(rs.getString(9));
            }
            
            int num = getInstructorID();
            
            setInstructorID(num + 1);
            
            // Close connection
            c1.close();

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**********************************************************************
 *                  Insert into Instructor Table
 **********************************************************************/      
    public void insertInstructorDB(){
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
            "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            // Execute SQL Statement
            Statement stmt = c1.createStatement();

            String sql = "Insert into Instructors values('"+getInstructorID()+"',"+
                                                    "'"+getInstructorFN()+"',"+ 
                                                    "'"+getInstructorLN()+"',"+
                                                    "'"+getInstructorStreet()+"',"+
                                                    "'"+getInstructorCity()+"',"+
                                                    "'"+getInstructorState()+"',"+
                                                    "'"+getInstructorZip()+"',"+
                                                    "'"+getInstructorOffice()+"',"+
                                                    "'"+getInstructorEmail()+"')";
            
            // Check if update was successfull or not
            int n1 = stmt.executeUpdate(sql);
            if(n1 == 1){
                System.out.println("Update Successfull!");
            }
            else{
                System.out.println("Update failed!");
            }
            
            // Close connection
            c1.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**********************************************************************
 *                  Delete Instructor from DB
 **********************************************************************/     
    public void instructorDelete(){
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" +
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            //Execute SQL Statement
            Statement stmt = c1.createStatement();
            String sql = " Delete from Instructors where ID = " + getInstructorID();
            
            // Print out sql
            System.out.println(sql);

            // Check if Delete worked
            int n = stmt.executeUpdate(sql);

            if (n==1)
                System.out.println("Delete Successful!");
            else
                System.out.println("Delete failed!");
            c1.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**********************************************************************
 *                  Display information
 **********************************************************************/      
    public void instructorDisplay(){
        System.out.println("==========================================");
        System.out.println("ID: " + getInstructorID());
        System.out.println("First Name: " + getInstructorFN());
        System.out.println("Last Name: " + getInstructorLN());
        System.out.println("Street: " + getInstructorStreet());
        System.out.println("City: " + getInstructorCity());
        System.out.println("State: " + getInstructorState());
        System.out.println("Zip: " + getInstructorZip());
        System.out.println("Office: " + getInstructorOffice());
        System.out.println("Email: " + getInstructorEmail());
        System.out.println("==========================================");
    }
    
    public void displayAllInstructors(){
        System.out.println(instructorList);
        
        int count = 1;
        int count2 = 2;
        int count3 = 3;
        int count4 = 4;
        int count5 = 5;
        int count6 = 6;
        int count7 = 7;
        int count8 = 8;
        
        for(int i = 0; i < instructorList.size(); i++){
            System.out.println("**************************");
            System.out.println("ID: " + instructorList.get(i));
            System.out.println("First Name: " + instructorList.get(count));
            System.out.println("Last Name: " + instructorList.get(count2));
            System.out.println("Street: " + instructorList.get(count3));
            System.out.println("City: " + instructorList.get(count4));
            System.out.println("State: " + instructorList.get(count5));
            System.out.println("Zip: " + instructorList.get(count6));
            System.out.println("Office: " + instructorList.get(count7));
            System.out.println("Email: " + instructorList.get(count8));
            System.out.println("**************************");
            
            count8 = count8 + 9;
            count7 = count7 + 9;
            count6 = count6 + 9;
            count5 = count5 + 9;
            count4 = count4 + 9;
            count3 = count3 + 9;
            count2 = count2 + 9;
            count = count + 9;
            i = i + 8;
        }
    }
    
    public static void main(String[] args){
        
        Instructor i1 = new Instructor();
        
//        i1.selectDB(1);
//        
//        i1.instructorDisplay();
   
        
        i1.getNextID();
        i1.setInstructorFN("Patricia");
        i1.setInstructorLN("Rivera");
        i1.setInstructorStreet("5784 Rando");
        i1.setInstructorCity("Fairburn");
        i1.setInstructorZip(12345);
        i1.setInstructorOffice("F8754");
        i1.setInstructorEmail("example@gmail.com");
        
        i1.insertInstructorDB();
        
        Instructor i2 = new Instructor();
        
        i2.getAllInstructors();
        i2.displayAllInstructors();
        
//        i1.getNextID();
//        
//        System.out.println(i1.getInstructorID());
    }
}
