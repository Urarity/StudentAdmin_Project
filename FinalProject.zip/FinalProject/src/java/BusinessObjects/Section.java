package BusinessObjects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/********************************************************************
 *	Java III - Section Business Object
 * 	Patricia Rivera	- Spring 2020
 *            Section.java
 ********************************************************************/
public class Section {
    // ***************** Properties ****************************
    int crn;
    String courseID;
    String timeDays;
    String roomNo;
    int instructor;
    String error;
    
    // Section List
    public List<String> sList = new ArrayList<String>();
    
    public Section(){
        this.crn = 0;
        this.courseID = "";
        this.timeDays = "";
        this.roomNo = "";
        this.instructor = 0;
    }
    
    public Section(int crn, String courseID, String timeDays, String roomNo, int instructor){
        this.crn = crn;
        this.courseID = courseID;
        this.timeDays = timeDays;
        this.roomNo = roomNo;
        this.instructor = instructor;
    }
    
/**********************************************************************
 *                  Setter / Getters
 **********************************************************************/
    
    // Set & get crn
    public void setCRN(int crn){
        this.crn = crn;
    }
    
    public int getCRN(){
        return this.crn;
    }
    
    // Set & get courseID
    public void setCourseID(String courseID){
        this.courseID = courseID;
    }
    
    public String getCourseID(){
        return this.courseID;
    }
    
    // Set & get timeDays
    public void setTimeDays(String timeDays){
        this.timeDays = timeDays;
    }
    
    public String getTimeDays(){
        return this.timeDays;
    }
    
    // Set & get roomNo
    public void setRoomNo(String roomNo){
        this.roomNo = roomNo;
    }
    
    public String getRoomNo(){
        return this.roomNo;
    }
    
    // Set & get instructor
    public void setInstructor(int instructor){
        this.instructor = instructor;
    }
    
    public int getInstructor(){
        return this.instructor;
    }
    
    // Set & get Error
    public void setError(String error){
        this.error = error;
    }
    
    public String getError(){
        return this.error;
    }
    
/**********************************************************************
 *                  Database Behaviors
 *                      Course.java
 **********************************************************************/
    
/**********************************************************************
 *                  Get Section By crn
 **********************************************************************/  
    
    public void selectSectionDB(int crn){
        // Set ID        
        setCRN(crn);
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Sections WHERE CRN = '"+getCRN()+"'";
            
            ResultSet rs = stmt.executeQuery(sql);
            
            // Run statement
            rs.next();
            
            sList.add(rs.getString(1));
            sList.add(rs.getString(2));
            sList.add(rs.getString(3));
            sList.add(rs.getString(4));
            sList.add(rs.getString(5));
            
            // Close result
            rs.close();
            
            // Close connection
            c1.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**********************************************************************
 *                  Get Section By courseID / with Teachers name
 **********************************************************************/      
    public void selectSectionDBCourseID(String courseID){
        
        Section s1 = new Section();
        Instructor i1 = new Instructor();  
        
        // Set ID        
        setCourseID(courseID);
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Sections WHERE CourseID = '"+getCourseID()+"'";
            
            ResultSet rs = stmt.executeQuery(sql);
            
                        
            if (!rs.next()){
                setError("Their is no available sections");
                System.out.println(getError());
            }
            else{
                
                setError("");
                
                // Run statement
                while(rs.next()){
                    sList.add(rs.getString(1));
                    sList.add(rs.getString(2));
                    sList.add(rs.getString(3));
                    sList.add(rs.getString(4));
                    sList.add(rs.getString(5));
                    
                    i1.selectDB(Integer.parseInt(rs.getString(4)));
                    sList.add(i1.getInstructorFN());
                    sList.add(i1.getInstructorLN());
                }

                // Close result
                rs.close();

                // Close connection
                c1.close();
                
            }
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**********************************************************************
 *                  Get Section By courseID / without teachers name
 **********************************************************************/      
    public void selectByCourseID(String courseID){
        
        // Set ID        
        setCourseID(courseID);
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Sections WHERE CourseID = '"+getCourseID()+"'";
            
            ResultSet rs = stmt.executeQuery(sql);

            while(rs.next()){
                sList.add(rs.getString(1));
                sList.add(rs.getString(2));
                sList.add(rs.getString(3));
                sList.add(rs.getString(4));
                sList.add(rs.getString(5));
            }

            // Close result
            rs.close();

            // Close connection
            c1.close();
            
            } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Section.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**********************************************************************
 *                  Get Section By Teacher
 **********************************************************************/      
    public void selectInstructorSectionDB(int instructor){
        
        Section s1 = new Section();
        Instructor i1 = new Instructor();        
        
        // Set ID        
        setInstructor(instructor);
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Sections WHERE Instructor = '"+getInstructor()+"'";
            
            ResultSet rs = stmt.executeQuery(sql);
            
            int count = 3;
            
            // Run statement
            while(rs.next()){
                sList.add(rs.getString(1));
                sList.add(rs.getString(2));
                sList.add(rs.getString(3));
                sList.add(rs.getString(4));
                sList.add(rs.getString(5));

                i1.selectDB(Integer.parseInt(rs.getString(4)));
                sList.add(i1.getInstructorFN());
                sList.add(i1.getInstructorLN());

            }

            // Close result
            rs.close();
            
            // Close connection
            c1.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**********************************************************************
 *                  Get All Sections
 **********************************************************************/      
    public void getAllSections(){
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL statement
            Statement stmt = c1.createStatement();
            String sql = "SELECT * FROM Sections";
            
            ResultSet rs = stmt.executeQuery(sql);
            
            // Run statement

            while(rs.next()){
                sList.add(rs.getString(1));
                sList.add(rs.getString(2));
                sList.add(rs.getString(3));
                sList.add(rs.getString(4));
                sList.add(rs.getString(5));
            }
            
            // Close connection
            c1.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
/**********************************************************************
 *                  Insert Section into DB
 **********************************************************************/  
    public void insertSection(){
        
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" + 
            "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            // Execute SQL Statement
            Statement stmt = c1.createStatement();
            
            String sql = "INSERT INTO Sections(CRN, CourseID, TimeDays, RoomNo, Instructor) "
                    + "VALUES('"+getCRN()+"',"+
                                "'"+getCourseID()+"',"+ 
                                "'"+getTimeDays()+"',"+
                                "'"+getRoomNo()+"',"+
                                "'"+getInstructor()+"')";
            
            // Check if update was successfull or not
            int n1 = stmt.executeUpdate(sql);
            if(n1 == 1){
                System.out.println("Update Successfull!");
            }
            else{
                System.out.println("Update failed!");
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(StudentSchedule.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**********************************************************************
 *                  Section Delete
 **********************************************************************/      
    public void sectionDelete(){
        try {
            // Load DB
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://" +
                    "C:\\Users\\HP\\Documents\\NetBeansProjects\\FinalProject\\src\\java\\Database\\RegistrationMDB.mdb");
            
            //Execute SQL Statement
            Statement stmt = c1.createStatement();
            String sql = " Delete from Sections where CRN = " + getCRN();
            
            // Print out sql
            System.out.println(sql);

            // Check if Delete worked
            int n = stmt.executeUpdate(sql);

            if (n==1)
                System.out.println("Delete Successful!");
            else
                System.out.println("Delete failed!");
            c1.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void sectionDisplay(){
        System.out.println(sList);
        int count = 4; // CourseID
        int count2 = 1; // TimeDays
        int count3 = 2; // RoomNo
        int count4 = 5; // Instructor
        int count5 = 6;
        
        System.out.println("=========================");
        for (int i = 0; i < sList.size(); i++){
            
            System.out.println("CRN: " + sList.get(i));
            System.out.println("CourseID: " + sList.get(count));
            System.out.println("TimeDays: " + sList.get(count2));
            System.out.println("RoomNo: " + sList.get(count3));
            System.out.println("Instructor: " + sList.get(count4) + " " + sList.get(count5));
            System.out.println("**********************************");
            
            count5 = count5 + 7;
            count4 = count4 + 7;
            count3 = count3 + 7;
            count2 = count2 + 7;
            count = count + 7;
            i = i + 6;
        }
        System.out.println("=========================");
    }
    
    public void display(){
        System.out.println("=========================");
        System.out.println("CRN: " + getCRN());
        System.out.println("CourseID: " + getCourseID());
        System.out.println("TimeDays: " + getTimeDays());
        System.out.println("RoomNo: " + getRoomNo());
        System.out.println("Instructor: " + getInstructor());
        System.out.println("=========================");
    }
    
    public void displayAllSections(){
        System.out.println(sList);
        int count = 1; // CourseID
        int count2 = 2; // TimeDays
        int count3 = 3; // RoomNo
        int count4 = 4; // Instructor
        
        System.out.println("=========================");
        for (int i = 0; i < sList.size(); i++){
            
            System.out.println("CRN: " + sList.get(i));
            System.out.println("Time Days: " + sList.get(count));
            System.out.println("Room Number: " + sList.get(count2));
            System.out.println("Instructor: " + sList.get(count3));
            System.out.println("Course ID: " + sList.get(count4));
            System.out.println("**********************************");
            
            count4 = count4 + 5;
            count3 = count3 + 5;
            count2 = count2 + 5;
            count = count + 5;
            i = i + 4;
        }
        System.out.println("=========================");       
    }

/**********************************************************************
 *                  Display information
 **********************************************************************/      
    public void displayNewSections(){
        System.out.println(sList);
        int count = 1; // CourseID
        int count2 = 2; // TimeDays
        int count3 = 3; // RoomNo
        int count4 = 4; // Instructor
        
        System.out.println("=========================");
        for (int i = 0; i < sList.size(); i++){
            
            System.out.println("CRN: " + sList.get(i));
            System.out.println("Time Days: " + sList.get(count));
            System.out.println("Room Number: " + sList.get(count2));
            System.out.println("Instructor: " + sList.get(count3));
            System.out.println("Course ID: " + sList.get(count4));
            System.out.println("**********************************");
            
            count4 = count4 + 5;
            count3 = count3 + 5;
            count2 = count2 + 5;
            count = count + 5;
            i = i + 4;
        }
        System.out.println("=========================");       
    }
    
    public static void main(String[] args){
        
        Section s = new Section();
        
        s.selectByCourseID("CIST 1776");
        
        s.displayNewSections();
        
//        
//        System.out.println("****By CRN****");
//        
//        s.selectSectionDB(30101);
//        
//        s.sectionDisplay();
        
//        System.out.println("****By Instructor****");
//        
//        s.selectInstructorSectionDB(1);
//        
//        s.sectionDisplay();
        
//        System.out.println("****By Course ID****");
        
//        s.selectSectionDBCourseID("CIST 1001");
//        s.selectSectionDBCourseID("CIST 1112");
        
//        s.sectionDisplay();

//        s.getAllSections();
//        
//        s.displayAllSections();
        
    }
}
