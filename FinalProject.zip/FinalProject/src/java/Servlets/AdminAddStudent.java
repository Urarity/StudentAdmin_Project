package Servlets;

import BusinessObjects.Course;
import BusinessObjects.Instructor;
import BusinessObjects.Section;
import BusinessObjects.Student;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**********************************************************************
 *      Java III - This Servlet adds Student to the AdminInstructors Page
 *                  Patricia Rivera - Spring 2020
 *                      AdminAddStudent.java Servlet
 **********************************************************************/
@WebServlet(name = "AdminAddStudent", urlPatterns = {"/AdminAddStudent"})
public class AdminAddStudent extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        // Get all the information
        String stfname = request.getParameter("stfname");
        String stlname = request.getParameter("stlname");
        String ststreet = request.getParameter("ststreet");
        String stcity = request.getParameter("stcity");
        String ststate = request.getParameter("ststate");
        String stzip = request.getParameter("stzip");
        String stemail = request.getParameter("stemail");
        
        // Get the BO
        Student s = new Student();

        s.getNextID(); // Get the next ID

        // Set all the new information
        s.setStudentFN(stfname);
        s.setStudentLN(stlname);
        s.setStreet(ststreet);
        s.setCity(stcity);
        s.setState(ststate);
        s.setZip(Integer.parseInt(stzip));
        s.setEmail(stemail);

        // Manually input GPA / Pass (GPA is always 0.0 & Pass is always 123)
        s.setGPA(0);
        s.setStudentPass("123");

        // Insert
        s.insertStudentDB();

        /** Get Instructor - Students - Sections - Courses**/
        Instructor i1 = new Instructor();
        Student s1 = new Student();
        Course c1 = new Course();
        Section s2 = new Section();

        // Get all Instructors - Students - Sections - Courses
        i1.getAllInstructors();
        s1.getAllStudents();
        c1.getAllCourses();
        s2.getAllSections();

        String location = "http://localhost:8080/FinalProject/AddedToDatabase.jsp";
        response.sendRedirect(location);

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
