package Servlets;

import BusinessObjects.Student;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/********************************************************************
 *	Java III - This servlet updates the Students Profile
 * 	Patricia Rivera	- Spring 2020
 *            stUpdate.java
 ********************************************************************/
@WebServlet(name = "stUpdate", urlPatterns = {"/stUpdate"})
public class stUpdate extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        /*** Get info from Textboxes **/
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String street = request.getParameter("street");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String zip = request.getParameter("zip"); // int
        String email = request.getParameter("email");
        String id = request.getParameter("studentid");
        
        /*** Printing out the info ***/
        System.out.println("****************************");
        System.out.println("Update Info:");
        System.out.println("First Name: " + fname);
        System.out.println("Last Name: " + lname);
        System.out.println("Street: " + street);
        System.out.println("City: " + city);
        System.out.println("State: " + state);
        System.out.println("ZIP: " + zip);
        System.out.println("Email: " + email);
        System.out.println("****************************");
        
        /*** Call the Student Object **/
        Student student1 = new Student();
        
        /*** Set new Info **/
        student1.setStudentID(Integer.parseInt(id));
        student1.setStudentFN(fname);
        student1.setStudentLN(lname);
        student1.setStreet(street);
        student1.setCity(city);
        student1.setState(state);
        student1.setZip(Integer.parseInt(zip));
        student1.setEmail(email);
        
        /** Update the Database **/
        student1.updateStudent();
        
        /** Get New Student Business Object **/
        Student s1 = new Student();
        
        /** Search the Student **/
        s1.selectDB(Integer.parseInt(id));
        
        /*** Put Student Object in session ***/
        HttpSession ses1;
        
        ses1 = request.getSession();
        
        ses1.setAttribute("s1", s1);
        
        /** Redirects to the accountLookup page **/
        RequestDispatcher rd = request.getRequestDispatcher("StudentProfile.jsp");

        rd.forward(request, response);
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
