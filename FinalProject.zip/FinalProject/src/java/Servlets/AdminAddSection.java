package Servlets;

import BusinessObjects.Course;
import BusinessObjects.Instructor;
import BusinessObjects.Section;
import BusinessObjects.Student;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**********************************************************************
 *      Java III - This Servlet adds Section to the AdminSections Page
 *                  Patricia Rivera - Spring 2020
 *                      AdminAddSection.java Servlet
 **********************************************************************/
@WebServlet(name = "AdminAddSection", urlPatterns = {"/AdminAddSection"})
public class AdminAddSection extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        // Get info
        String crn = request.getParameter("crn");
        String courseID = request.getParameter("courseID");
        String timedays = request.getParameter("timedays");
        String roomNo = request.getParameter("roomNo");
        String instructorID = request.getParameter("instructorID");
        
        // Get the Section BO
        Section s3 = new Section();
        
        // Set all the information
        s3.setCRN(Integer.parseInt(crn));
        s3.setCourseID(courseID);
        s3.setTimeDays(timedays);
        s3.setRoomNo(roomNo);
        s3.setInstructor(Integer.parseInt(instructorID));
        
        // Input the new Section
        s3.insertSection();
        
        /** Get Instructor - Students - Sections - Courses**/
        Instructor i1 = new Instructor();
        Student s1 = new Student();
        Course c1 = new Course();
        Section s2 = new Section();
        
        // Get all Instructors - Students - Sections - Courses
        i1.getAllInstructors();
        s1.getAllStudents();
        c1.getAllCourses();
        s2.getAllSections();

        String location = "http://localhost:8080/FinalProject/AddedToDatabase.jsp";
        response.sendRedirect(location);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
