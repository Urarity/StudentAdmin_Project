package Servlets;

import BusinessObjects.Instructor;
import BusinessObjects.Section;
import BusinessObjects.Student;
import BusinessObjects.StudentSchedule;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**********************************************************************
 *      Java III - This Servlet Logins Student depending on input
 *                  Patricia Rivera - Spring 2020
 *                      StudentLoginServlet.java Servlet
 **********************************************************************/
@WebServlet(name = "StudentLoginServlet", urlPatterns = {"/StudentLoginServlet"})
public class StudentLoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        /*** Get info from Textboxes **/
        String stFirstName = request.getParameter("studentFirstName");
        String stLastName = request.getParameter("studentLastName");
        String stPassword = request.getParameter("studentPass");
        
        /*** Get Info from StudentSection.jsp **/
        String id = request.getParameter("ID");
        String sectionCRN = request.getParameter("crnChosen");
        
        if(!id.equals("") && !sectionCRN.equals("")){
            
            // Get the database
            Student s2 = new Student();
            StudentSchedule ss2 = new StudentSchedule();
            
            // Find Database
            s2.selectDB(Integer.parseInt(id));
            ss2.selectDB(id);
            
            // Add crn / ID
            ss2.setID(id);
            ss2.setCRN(sectionCRN);

            // Insert into database
            ss2.insertDB();
            
            /*** Call the Student / StudentSchedule Object **/
            Student s1 = new Student();
            StudentSchedule ss1 = new StudentSchedule();
            Instructor i1 = new Instructor();
            Section s = new Section();
        
            /** Find the database by firstname **/
            s1.selectDB(Integer.parseInt(id));
            ss1.selectDB(id);
            
            /*** Put Student and StudentSchedule Object in session ***/
            HttpSession ses1;

            ses1 = request.getSession();

            ses1.setAttribute("s1", s1);
            ses1.setAttribute("ss1", ss1);
            ses1.setAttribute("i1", i1);
            ses1.setAttribute("s", s);           
            
            /** Redirects to the accountLookup page **/
            RequestDispatcher rd = request.getRequestDispatcher("StudentSchedule.jsp");

            rd.forward(request, response);
        
        }
        else{
        
            /*** Printing out the info ***/
            System.out.println("****************************");
            System.out.println("First Name = " + stFirstName);
            System.out.println("Last Name = " + stLastName);
            System.out.println("Password = " + stPassword);
            System.out.println("****************************");

            /*** Call the Student / StudentSchedule Object **/
            Student s1 = new Student();
            StudentSchedule ss1 = new StudentSchedule();
            Instructor i1 = new Instructor();
            Section s = new Section();

            /** Find the database by firstname **/
            s1.selectLoginDB(stFirstName, stLastName, stPassword);
            ss1.selectDB(Integer.toString(s1.getStudentID()));

            /** Get the password from the database **/
            String DBpass = s1.getStudentPass();
            System.out.println(DBpass); // test
            
            s1.setError("");
            
            /*** Put Student and StudentSchedule Object in session ***/
            HttpSession ses1;

            ses1 = request.getSession();

            ses1.setAttribute("s1", s1);
            ses1.setAttribute("ss1", ss1);
            ses1.setAttribute("i1", i1);
            ses1.setAttribute("s", s);

            /** If stPassword equals the password from the database searched up)**/
            if (stPassword.equals(DBpass)){ 

                /** Reset error **/
                s1.setError("");

                /** Prints in Console Valid Login **/
                System.out.println("Valid Login");

                /** Transfer the cust_id and cust_pass variable to the page **/
                request.setAttribute("stFirstName",stFirstName);
                request.setAttribute("stLastName",stLastName);

                /** Redirects to the accountLookup page **/
                RequestDispatcher rd = request.getRequestDispatcher("StudentSchedule.jsp");

                rd.forward(request, response);

            }
            else {

                /** Prints in Console Valid Login **/
                System.out.println("InValid Login");

                /** Transfer the cust_id and cust_pass variable to the page **/
                request.setAttribute("stFirstName",stFirstName);
                request.setAttribute("stLastName",stLastName);

                /** Redirects to the accountLookup page **/
                RequestDispatcher rd = request.getRequestDispatcher("StudentInvalid.jsp");

                rd.forward(request, response); 

            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
