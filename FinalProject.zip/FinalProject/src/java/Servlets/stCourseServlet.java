package Servlets;

import BusinessObjects.Course;
import BusinessObjects.Section;
import BusinessObjects.Student;
import BusinessObjects.StudentSchedule;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**********************************************************************
 *      Java III - This Servlet Changes the StudentSchedule page depending on the info
 *                  Patricia Rivera - Spring 2020
 *                      stCourseServlet.java Servlet
 **********************************************************************/
@WebServlet(name = "stCourseServlet", urlPatterns = {"/stCourseServlet"})
public class stCourseServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // Get Informatino from StudentSchedule
        String studentID = request.getParameter("studentInformation");
        String crn = request.getParameter("CourseRoomNo");
        
        String bool = request.getParameter("change");
        
        if(bool.equals("StudentSchedule")){
        
            if (!crn.equals("")){
                  
                // Call the BO I need
                StudentSchedule ss = new StudentSchedule();
                
                // Get Student Information
                ss.selectDB(studentID);
                ss.selectDB(studentID);
                
                // set information
                ss.setID(studentID);
                ss.setCRN(crn);

                // Delete
                ss.deleteDB();       

                // Get the new info from Business Objects
                StudentSchedule ss1 = new StudentSchedule();
                Student s1 = new Student();
                Course c1 = new Course();
                Section s = new Section();
                
                ss1.selectDB(studentID);
                s1.selectDB(Integer.parseInt(studentID));
                s.getAllSections();
                c1.getAllCourses();   
                
                /*** Put Objects in session ***/
                HttpSession ses1;

                ses1 = request.getSession();

                ses1.setAttribute("s1", s1);
                ses1.setAttribute("ss1", ss1);
                ses1.setAttribute("c1", c1);
                ses1.setAttribute("s", s);
                                
                /** Redirects to the accountLookup page **/
                RequestDispatcher rd = request.getRequestDispatcher("StudentSchedule.jsp");

                rd.forward(request, response);
            }
            else if(crn.equals("")) {

                // Get the new info from Business Objects
                Student s1 = new Student();
                Course c1 = new Course();
                Section s = new Section();
                StudentSchedule ss1 = new StudentSchedule();
                
                // SelectDB for Student
                s1.selectDB(Integer.parseInt(studentID));
                s.getAllSections();
                c1.getAllCourses();   
                ss1.selectDB(studentID);
                                
                s1.setError("Course");
                
                /*** Put Objects in session ***/
                HttpSession ses1;

                ses1 = request.getSession();

                ses1.setAttribute("s1", s1);
                ses1.setAttribute("c1", c1);
                ses1.setAttribute("s", s);
                ses1.setAttribute("ss1", ss1);
                                
                /** Redirects to the accountLookup page **/
                RequestDispatcher rd = request.getRequestDispatcher("StudentSchedule.jsp");

                rd.forward(request, response);
            }   
        }
        else if(bool.equals("Section")){

            String crn2 = request.getParameter("classChosen");
            String id = request.getParameter("ID");
            String sectionCRN = request.getParameter("crnChosen"); 
            
            // Get the new info from Business Objects
            Student s1 = new Student();
            Section s = new Section();
            StudentSchedule ss1 = new StudentSchedule();
            Course c1 = new Course();
            
            // Find Database
            s1.selectDB(Integer.parseInt(id));
            s.selectByCourseID(sectionCRN);
            ss1.selectDB(id);
            c1.getAllCourses();
            
            s1.setError("Section");
            s.setError("");
            
            /*** Put Objects in session ***/
            HttpSession ses1;

            ses1 = request.getSession();

            ses1.setAttribute("s1", s1);
            ses1.setAttribute("s", s);
            ses1.setAttribute("c1", c1);
            ses1.setAttribute("ss1", ss1);

            /** Redirects to the accountLookup page **/
            RequestDispatcher rd = request.getRequestDispatcher("StudentSchedule.jsp");

            rd.forward(request, response);

        }  
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
