package Servlets;

import BusinessObjects.Course;
import BusinessObjects.Instructor;
import BusinessObjects.Section;
import BusinessObjects.Student;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**********************************************************************
 *      Java III - This Servlet adds Instructor to the AdminInstructors Page
 *                  Patricia Rivera - Spring 2020
 *                      AdminAddInstructor.java Servlet
 **********************************************************************/
@WebServlet(name = "AdminAddInstructor", urlPatterns = {"/AdminAddInstructor"})
public class AdminAddInstructor extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

            // Get all the information
            String InstructorFName = request.getParameter("infname");
            String InstructorLName = request.getParameter("inlname");
            String InstructorStreet = request.getParameter("instreet");
            String InstructorCity = request.getParameter("incity");
            String InstructorState = request.getParameter("instate");
            String InstructorZip = request.getParameter("inzip");
            String InstructorOffice = request.getParameter("inoffice");
            String InstructorEmail = request.getParameter("inemail");

            // Get the Instructor BO
            Instructor i2 = new Instructor();

            // Get the next instructorID
            i2.getNextID();

            // Set all the information
            i2.setInstructorFN(InstructorFName);
            i2.setInstructorLN(InstructorLName);
            i2.setInstructorStreet(InstructorStreet);
            i2.setInstructorCity(InstructorCity);
            i2.setInstructorState(InstructorState);
            i2.setInstructorZip(Integer.parseInt(InstructorZip));
            i2.setInstructorOffice(InstructorOffice);
            i2.setInstructorEmail(InstructorEmail);

            // Input the new Instructor
            i2.insertInstructorDB();

            /** Get Instructor - Students - Sections - Courses**/
            Instructor i1 = new Instructor();
            Student s1 = new Student();
            Course c1 = new Course();
            Section s2 = new Section();

            // Get all Instructors - Students - Sections - Courses
            i1.getAllInstructors();
            s1.getAllStudents();
            c1.getAllCourses();
            s2.getAllSections();

            String location = "http://localhost:8080/FinalProject/AddedToDatabase.jsp";
            response.sendRedirect(location);

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
