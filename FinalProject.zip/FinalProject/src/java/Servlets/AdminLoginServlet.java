package Servlets;

import BusinessObjects.Course;
import BusinessObjects.Instructor;
import BusinessObjects.Section;
import BusinessObjects.Student;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**********************************************************************
 *      Java III - This Servlet Logins Admin depending on input
 *                  Patricia Rivera - Spring 2020
 *                      AdminLoginServlet.java Servlet
 **********************************************************************/
@WebServlet(name = "AdminLoginServlet", urlPatterns = {"/AdminLoginServlet"})
public class AdminLoginServlet extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String adminUser = request.getParameter("adminUser");
        String adminPass = request.getParameter("adminPass");

        if(adminUser.equals("admin")){
            if(adminPass.equals("123")){

                /** Get Instructor - Students - Sections - Courses**/
                Instructor i1 = new Instructor();
                Student s1 = new Student();
                Course c1 = new Course();
                Section s2 = new Section();

                // Get all Instructors - Students - Sections - Courses
                i1.getAllInstructors();
                s1.getAllStudents();
                c1.getAllCourses();
                s2.getAllSections();

                /*** Put Objects in session ***/
                HttpSession ses1;

                ses1 = request.getSession();

                ses1.setAttribute("i1", i1);
                ses1.setAttribute("s1", s1);
                ses1.setAttribute("c1", c1);
                ses1.setAttribute("s2", s2);

                /** Redirects to the page **/
                String location = "http://localhost:8080/FinalProject/AdminInstructors.jsp";
                response.sendRedirect(location);
            }
            else{
                /*** Put Information in session ***/
                HttpSession ses1;

                ses1 = request.getSession();

                String error = "Wrong Password";

                ses1.setAttribute("error", error);

                /** Redirects to the page **/
                RequestDispatcher rd = request.getRequestDispatcher("AdminInvalid.jsp");

                rd.forward(request, response);  
            }
        }
        else{

            /*** Put Information in session ***/
            HttpSession ses1;

            ses1 = request.getSession();

            String error = "Wrong Username";

            ses1.setAttribute("error", error);

            /** Redirects to the page **/
            RequestDispatcher rd = request.getRequestDispatcher("AdminInvalid.jsp");

            rd.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
