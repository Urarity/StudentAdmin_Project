/********************************************************************
 *	Java III - check JavaScript
 * 	Patricia Rivera	- Spring 2020
 *            check.js
 ********************************************************************/

// ********************** StudentLogin.jsp *************************************

function checkStudentLogin(){
    var fullname = document.getElementById("studentUserName"); // Var fullname
        
    var first = document.getElementById("studentFirstName").value = fullname.value.split(" ")[0];;
    var last = document.getElementById("studentLastName").value = fullname.value.split(" ")[1];
            
//    alert(first);
//    alert(last);
}

function wrongFullName(){
    var userName = document.getElementById("studentUserName");
    
    userName.style.border = "2px solid red"; // Change border color
    userName.setCustomValidity("Please Enter a valid Name"); // custom validity
    
    document.getElementById("studentUserName").title = "Please Enter a valid Name";
    
    return false;
}

function resetFullName(){
    var userName = document.getElementById("studentUserName");
    
    userName.style.border = "1px solid black"; // Change border color
    userName.setCustomValidity(""); // custom validity
    
    document.getElementById("studentUserName").title = "";
    
    return true;
}

function wrongPass(){
    var userPass = document.getElementById("studentPass");
    
    userPass.style.border = "2px solid red"; // Change border color
    userPass.setCustomValidity("Please Enter a valid Password"); // custom validity
    
    document.getElementById("studentPass").title = "Please Enter a valid Password";
    
    return false;
}

function restPass(){
    var userPass = document.getElementById("studentPass");
    
    userPass.style.border = "1px solid black"; // Change border color
    userPass.setCustomValidity(""); // custom validity
    
    document.getElementById("studentPass").title = "";
    
    return true;   
}
// ********************** End StudentLogin.jsp *************************************

// ********************** AdminLogin.jsp *************************************

function wrongAdminUser(){
    var adminUser = document.getElementById("adminUser");
    
    adminUser.style.border = "2px solid red"; // Change border color
    adminUser.setCustomValidity("Please Enter a valid username"); // custom validity
    
    document.getElementById("adminUser").title = "Please Enter a valid username";
    
    return false;
}

function resetAdminUser(){
    var adminUser = document.getElementById("adminUser");
    
    adminUser.style.border = "1px solid black"; // Change border color
    adminUser.setCustomValidity(""); // custom validity
    
    document.getElementById("adminUser").title = "";
    
    return true;    
}

function wrongAdminPass(){
    var adminPass = document.getElementById("adminPass");
    
    adminPass.style.border = "2px solid red"; // Change border color
    adminPass.setCustomValidity("Please Enter a valid password"); // custom validity
    
    document.getElementById("adminPass").title = "Please Enter a valid password";
    
    return false;    
}

function resetAdminPass(){
    var adminPass = document.getElementById("adminPass");
    
    adminPass.style.border = "1px solid black"; // Change border color
    adminPass.setCustomValidity(""); // custom validity
    
    document.getElementById("adminPass").title = "";
    
    return true;    
}

// ********************** End AdminLogin.jsp *************************************

function courses(i, id){
    var btn = document.getElementById("btn" + i + ""); // btn variable
    
    var chose = document.getElementById("CourseID" + i + "");
    
    var chosen = document.getElementById("classChosen"); // chosen variable
    
    var c = document.getElementById("crnChosen");
    
    var ID = document.getElementById("ID");
    
    document.getElementById("crnChosen").value = chose.value;        
    
    document.getElementById("classChosen").value = chose.value;
//    alert(id); // test
//    alert(ID.value); // test    
//    alert(chosen.value); // test
//    alert(c.value);
//    alert(chose.value);
    
    return true;

}

function section(i, id){
    var crn = document.getElementById("crnChosen"); // chosen variable
    
    var crn = document.getElementById("CRN" + i + "");
    
    var crn = document.getElementById("crnChosen").value = crn.value;

//    alert(id);
//    alert(crn.value);    
//    alert(crn);
    
}

function student(i, id){
    var crn = document.getElementById("CRN" + i + "");
       
    var courseRoom = document.getElementById("CourseRoomNo");
    
    courseRoom.value = crn.value;
    
//    alert(id);
//    alert(crn.value);    
//    alert(courseRoom.value);
}

function adminPage(){
    var good_bad = document.getElementById("good_bad");
    
    good_bad.value = "bad";
}

function addPage(){
    var good_bad = document.getElementById("good_bad");
    
    good_bad.value = "good";
    
}

// ********************** StudentLogin.jsp *************************************

function spFNWrong(){
    var fname = document.getElementById("fname");
    
    fname.style.border = "2px solid red"; // Change border color
    fname.setCustomValidity("Please Enter a valid First Name"); // custom validity
    
    document.getElementById("fname").title = "Please Enter a valid First Name";
    
    return false;
}

function spFNReset(){
    var fname = document.getElementById("fname");
    
    fname.style.border = "1px solid black"; // Change border color
    fname.setCustomValidity(""); // custom validity
    
    document.getElementById("fname").title = "";
    
    return true;
}

function spLNWrong(){
    var lname = document.getElementById("lname");
    
    lname.style.border = "2px solid red"; // Change border color
    lname.setCustomValidity("Please Enter a valid Last Name"); // custom validity
    
    document.getElementById("lname").title = "Please Enter a valid Last Name";
    
    return false;
}

function spLNReset(){
    var lname = document.getElementById("lname");
    
    lname.style.border = "1px solid black"; // Change border color
    lname.setCustomValidity(""); // custom validity
    
    document.getElementById("lname").title = "";
    
    return true;    
}

function streetWrong(){
    var street = document.getElementById("street");
    
    street.style.border = "2px solid red"; // Change border color
    street.setCustomValidity("Please Enter a valid Street"); // custom validity
    
    document.getElementById("street").title = "Please Enter a valid Street";
    
    return false;    
}

function streetReset(){
    var street = document.getElementById("street");
    
    street.style.border = "1px solid black"; // Change border color
    street.setCustomValidity(""); // custom validity
    
    document.getElementById("street").title = "";
    
    return true;     
}

function cityWrong(){
    var city = document.getElementById("city");
    
    city.style.border = "2px solid red"; // Change border color
    city.setCustomValidity("Please Enter a valid City"); // custom validity
    
    document.getElementById("city").title = "Please Enter a valid City";
    
    return false;     
}

function cityReset(){
    var city = document.getElementById("city");
    
    city.style.border = "1px solid black"; // Change border color
    city.setCustomValidity(""); // custom validity
    
    document.getElementById("city").title = "";
    
    return true;     
}

function stateWrong(){
    var state = document.getElementById("state");
    
    state.style.border = "2px solid red"; // Change border color
    state.setCustomValidity("Please Enter a valid State Abbrev."); // custom validity
    
    document.getElementById("state").title = "Please Enter a valid State Abbrev.";
    
    return false;
}

function stateReset(){
    var state = document.getElementById("state");
    
    state.style.border = "1px solid black"; // Change border color
    state.setCustomValidity(""); // custom validity
    
    document.getElementById("state").title = "";
    
    return true;       
}

function zipWrong(){
    var zip = document.getElementById("zip");
    
    zip.style.border = "2px solid red"; // Change border color
    zip.setCustomValidity("Please Enter a valid Zip 5 Ints only"); // custom validity
    
    document.getElementById("zip").title = "Please Enter a valid Zip 5 Ints only";
    
    return false;    
}

function zipReset(){
    var zip = document.getElementById("zip");
    
    zip.style.border = "1px solid black"; // Change border color
    zip.setCustomValidity(""); // custom validity
    
    document.getElementById("zip").title = "";
    
    return true;    
}

function emailWrong(){
    var email = document.getElementById("email");
    
    email.style.border = "2px solid red"; // Change border color
    email.setCustomValidity("Please Enter a valid email"); // custom validity
    
    document.getElementById("email").title = "Please Enter a valid email";
    
    return false;     
}

function emailReset(){
    var email = document.getElementById("email");
    
    email.style.border = "1px solid black"; // Change border color
    email.setCustomValidity(""); // custom validity
    
    document.getElementById("email").title = "";
    
    return true;     
}

// ********************** end StudentLogin.jsp *************************************